1. setup NDK && ADB
2. connect android (usb debugging enabled)
4. make test
